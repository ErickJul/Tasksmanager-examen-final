from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from .views import task_list, create_task, edit_task, task_toggle_complete, task_delete

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'), 
    path('task/<int:id>/', views.task_detail, name='task_detail'),
    path("create/", views.create_task, name="create_task"),
    path('task/<int:id>/edit/', views.edit_task, name='edit_task'), 
    path('tasks/', views.task_list, name='task_list'),
    path('task/<int:id>/complete/', views.mark_task_completed, name='mark_task_completed'),
    path('task/<int:id>/delete/', views.delete_task, name='delete_task'),
]
