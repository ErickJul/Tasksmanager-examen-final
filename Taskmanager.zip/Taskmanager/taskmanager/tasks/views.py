from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages


@login_required
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('task_list') 
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

#---------------------------------------------------------------

from django.shortcuts import render
from .models import Task

@login_required
def task_list(request):
    tasks = Task.objects.filter(user=request.user) 
    return render(request, 'tasks/task_list.html', {'tasks': tasks})

#---------------------------------------------------------------

from django.shortcuts import render, get_object_or_404
from .models import Task

@login_required
def task_detail(request, id):
    task = get_object_or_404(Task, id=id, user=request.user)
    return render(request, 'tasks/task_detail.html', {'task': task})

#---------------------------------------------------------------

from django.shortcuts import render, redirect
from .forms import TaskForm

@login_required
def create_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.user = request.user 
            task.save()
            return redirect('task_list')
    else:
        form = TaskForm()
    return render(request, 'tasks/create_task.html', {'form': form})

#---------------------------------------------------------------

from django.shortcuts import render, get_object_or_404, redirect
from .forms import TaskForm
from .models import Task

@login_required
def edit_task(request, id):
    task = get_object_or_404(Task, id=id, user=request.user)
    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect('task_list')  
    else:
        form = TaskForm(instance=task)
    return render(request, 'tasks/edit_task.html', {'form': form})

#---------------------------------------------------------------

from django.shortcuts import get_object_or_404, redirect
from .models import Task

@login_required
def mark_task_completed(request, id):
    task = get_object_or_404(Task, id=id, user=request.user)
    task.completed = True
    task.save()
    return redirect('task_list')  

#---------------------------------------------------------------

from django.shortcuts import get_object_or_404, render, redirect
from .models import Task

@login_required
def delete_task(request, id):
    task = get_object_or_404(Task, id=id, user=request.user)
    if request.method == 'POST':
        task.delete()
        return redirect('task_list') 
    return render(request, 'tasks/delete_task.html', {'task': task})

#---------------------------------------------------------------

@login_required
def task_detail(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    return render(request, "tasks/task_detail.html", {"task": task})

#---------------------------------------------------------------

@login_required
def task_edit(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    
    if request.method == "POST":
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            return redirect("task_list")
    else:
        form = TaskForm(instance=task)
    
    return render(request, "tasks/task_form.html", {"form": form, "title": "Editar Tarea"})

#---------------------------------------------------------------

@login_required
def task_toggle_complete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.completed = not task.completed
    task.save()
    return redirect("task_list")

#---------------------------------------------------------------

@login_required
def task_delete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    
    if request.method == "POST":
        task.delete()
        messages.success(request, "Tarea eliminada con éxito.")
        return redirect("task_list")

    return render(request, "tasks/task_confirm_delete.html", {"task": task})

#---------------------------------------------------------------

from django.contrib.auth.views import LoginView

class CustomLoginView(LoginView):
    template_name = "tasks/login.html"
